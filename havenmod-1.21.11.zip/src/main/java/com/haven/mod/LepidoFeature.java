package com.haven.mod;

import com.mojang.serialization.Codec;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

public class LepidoFeature extends Feature<DefaultFeatureConfig> {
    public LepidoFeature() {
        super(DefaultFeatureConfig.CODEC);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> context) {
        StructureWorldAccess world = context.getWorld();
        BlockPos origin = context.getOrigin();
        if (!world.getBlockState(origin.down()).isIn(BlockTags.DIRT)) return false;
        return LepidoTree.generate(world, origin, context.getRandom(), false);
    }
}
