package com.haven.mod;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.server.world.ServerWorld;

/**
 * Атрибут attack_damage в Minecraft ограничен значением 2048, поэтому
 * недостающий урон до 7777 добавляется дополнительным ударом.
 */
public class GalaxyAxeItem extends AxeItem {
    public static final float TOTAL_DAMAGE = 7777.0f;

    public GalaxyAxeItem(ToolMaterial material, float damage, float speed, Settings settings) {
        super(material, damage, speed, settings);
    }

    @Override
    public void postDamageEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postDamageEntity(stack, target, attacker);
        if (target.getEntityWorld() instanceof ServerWorld world && target.isAlive()) {
            target.damage(world, (attacker instanceof net.minecraft.entity.player.PlayerEntity pl ? world.getDamageSources().playerAttack(pl) : world.getDamageSources().mobAttack(attacker)), TOTAL_DAMAGE);
        }
    }
}
