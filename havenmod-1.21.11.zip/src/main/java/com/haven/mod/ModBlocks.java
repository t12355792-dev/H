package com.haven.mod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.intprovider.UniformIntProvider;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {
    public static final List<Item> BLOCK_ITEMS = new ArrayList<>();

    public static final Block FROSTIUM_ORE = ore("frostium_ore", 3.0f, MapColor.LIGHT_BLUE);
    public static final Block THUNDERITE_ORE = ore("thunderite_ore", 3.0f, MapColor.YELLOW);
    public static final Block INFERNIUM_ORE = ore("infernium_ore", 3.5f, MapColor.RED);
    public static final Block CELESTITE_ORE = ore("celestite_ore", 4.0f, MapColor.WHITE);
    public static final Block HAVENITE_ORE = ore("havenite_ore", 5.0f, MapColor.PURPLE);

    public static final Block LEPIDODENDRON_LOG = simple("lepidodendron_log",
            st -> new PillarBlock(st.mapColor(MapColor.BROWN).strength(2.0f).sounds(BlockSoundGroup.WOOD)));
    public static final Block LEPIDODENDRON_SCALES = simple("lepidodendron_scales",
            st -> new Block(st.mapColor(MapColor.GREEN).strength(0.8f).sounds(BlockSoundGroup.GRASS)));

    private static Block simple(String name, java.util.function.Function<AbstractBlock.Settings, Block> factory) {
        Identifier id = HavenMod.id(name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        Block block = factory.apply(AbstractBlock.Settings.create().registryKey(blockKey));
        Registry.register(Registries.BLOCK, blockKey, block);
        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);
        BlockItem item = new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, itemKey, item);
        BLOCK_ITEMS.add(item);
        return block;
    }

    private static Block ore(String name, float hardness, MapColor color) {
        Identifier id = HavenMod.id(name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        Block block = new ExperienceDroppingBlock(UniformIntProvider.create(3, 7),
                AbstractBlock.Settings.create().mapColor(color).strength(hardness, 3.0f)
                        .requiresTool().sounds(BlockSoundGroup.STONE).registryKey(blockKey));
        Registry.register(Registries.BLOCK, blockKey, block);

        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);
        BlockItem item = new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, itemKey, item);
        BLOCK_ITEMS.add(item);
        return block;
    }

    public static void init() {}
}
