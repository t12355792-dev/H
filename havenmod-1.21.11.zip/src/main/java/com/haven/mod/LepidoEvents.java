package com.haven.mod;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Редкий спавн лепидодендрона, телепорт в измерение, смерть через 2 минуты, команда /lepidodendron. */
public final class LepidoEvents {
    public static final RegistryKey<World> DIMENSION = RegistryKey.of(RegistryKeys.WORLD, HavenMod.id("lepidodendron"));
    private static final int DEATH_TICKS = 2 * 60 * 20;      // 2 минуты
    private static final int TRIGGER_RADIUS = 7;             // блоков
    private static final int SPAWN_CHANCE = 180;             // раз в 10 сек шанс 1/180 (~раз в 30 минут)
    private static final Map<UUID, Integer> TIMERS = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(LepidoEvents::tickWorld);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("lepidodendron").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    ServerWorld world = (ServerWorld) player.getEntityWorld();
                    Vec3d look = Vec3d.fromPolar(0, player.getYaw());   // горизонтальное направление взгляда
                    int x = (int) Math.floor(player.getX() + look.x * 20);
                    int z = (int) Math.floor(player.getZ() + look.z * 20);
                    int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                    LepidoTree.generate(world, new BlockPos(x, y, z), world.getRandom(), true);
                    ctx.getSource().sendFeedback(() -> Text.literal("§2Лепидодендрон появился в 20 блоках от тебя..."), false);
                    return 1;
                })));
    }

    private static void tickWorld(ServerWorld world) {
        boolean inDimension = world.getRegistryKey().equals(DIMENSION);
        long time = world.getTime();

        for (PlayerEntity pe : world.getPlayers()) {
            if (!(pe instanceof ServerPlayerEntity player) || player.isSpectator() || !player.isAlive()) continue;

            if (inDimension) {
                tickDeathTimer(world, player);
                continue;
            }
            TIMERS.remove(player.getUuid());

            if (time % 10 == 0 && isNearTree(world, player)) {
                teleportToDimension(world, player);
                continue;
            }
            if (time % 200 == 0 && world.getRegistryKey().equals(World.OVERWORLD) && world.getRandom().nextInt(SPAWN_CHANCE) == 0) {
                trySpawnNear(world, player);
            }
        }
    }

    private static boolean isNearTree(ServerWorld world, ServerPlayerEntity player) {
        BlockPos center = player.getBlockPos();
        Vec3d pos = new Vec3d(player.getX(), player.getY(), player.getZ());
        int r = TRIGGER_RADIUS;
        for (BlockPos p : BlockPos.iterate(center.add(-r, -r, -r), center.add(r, r, r))) {
            if (world.getBlockState(p).isOf(ModBlocks.LEPIDODENDRON_LOG)
                    && p.toCenterPos().squaredDistanceTo(pos) <= r * r) {
                return true;
            }
        }
        return false;
    }

    private static void teleportToDimension(ServerWorld from, ServerPlayerEntity player) {
        ServerWorld target = from.getServer().getWorld(DIMENSION);
        if (target == null) return;
        int y = target.getTopY(Heightmap.Type.MOTION_BLOCKING, 8, 8);
        TIMERS.put(player.getUuid(), 0);
        player.teleport(target, 8.5, y, 8.5, Set.of(), player.getYaw(), player.getPitch(), true);
        player.sendMessage(Text.literal("§4Лепидодендрон затянул тебя в другой мир... У тебя есть 2 минуты."), false);
    }

    private static void tickDeathTimer(ServerWorld world, ServerPlayerEntity player) {
        int t = TIMERS.merge(player.getUuid(), 1, Integer::sum);
        int left = DEATH_TICKS - t;
        if (t % 20 == 0) {
            player.sendMessage(Text.literal("§c☠ До смерти: " + (left / 20) + " с"), true);
        }
        if (left <= 0) {
            TIMERS.remove(player.getUuid());
            player.kill(world);
        }
    }

    private static void trySpawnNear(ServerWorld world, ServerPlayerEntity player) {
        double angle = world.getRandom().nextDouble() * Math.PI * 2;
        double dist = 24 + world.getRandom().nextInt(24);
        int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
        int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
        if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) return;
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        if (!world.getBlockState(pos.down()).isIn(BlockTags.DIRT)) return;
        LepidoTree.generate(world, pos, world.getRandom(), false);
    }

    private LepidoEvents() {}
}
