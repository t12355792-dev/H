package com.haven.mod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;

/** Лепидодендрон: высокий ствол с дихотомическим (Y-образным) ветвлением и пучками чешуи на концах. */
public final class LepidoTree {
    private static final int[][] DIRS = {{1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}};

    /** @param base позиция первого блока ствола (над землёй). */
    public static boolean generate(StructureWorldAccess world, BlockPos base, Random random, boolean forceSoil) {
        if (forceSoil) {
            BlockState below = world.getBlockState(base.down());
            if (below.isAir() || !below.getFluidState().isEmpty() || below.isReplaceable()) {
                world.setBlockState(base.down(), Blocks.DIRT.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        BlockState log = ModBlocks.LEPIDODENDRON_LOG.getDefaultState();
        int height = 18 + random.nextInt(9);
        for (int y = 0; y < height; y++) place(world, base.up(y), log);
        // расширение у основания (корни)
        for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
            place(world, base.add(d[0], 0, d[1]), log);
            if (random.nextBoolean()) place(world, base.add(d[0], 1, d[1]), log);
        }
        BlockPos top = base.up(height);
        int dir = random.nextInt(8);
        branch(world, top, dir, 4, 0);
        branch(world, top, (dir + 4) % 8, 4, 0);
        return true;
    }

    private static void branch(StructureWorldAccess world, BlockPos start, int dir, int len, int depth) {
        BlockState log = ModBlocks.LEPIDODENDRON_LOG.getDefaultState();
        int[] d = DIRS[dir];
        BlockPos p = start;
        for (int i = 0; i < len; i++) {
            p = p.add(d[0], (i % 2 == 0) ? 1 : 0, d[1]);
            place(world, p, log);
        }
        if (depth < 2) {
            int next = Math.max(2, len - 1);
            branch(world, p, (dir + 7) % 8, next, depth + 1);
            branch(world, p, (dir + 1) % 8, next, depth + 1);
        } else {
            crown(world, p);
        }
    }

    private static void crown(StructureWorldAccess world, BlockPos tip) {
        BlockState scales = ModBlocks.LEPIDODENDRON_SCALES.getDefaultState();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx * dx + dy * dy + dz * dz <= 5) place(world, tip.add(dx, dy, dz), scales);
                }
            }
        }
        for (int i = 3; i <= 5; i++) place(world, tip.up(i), scales);
    }

    private static void place(StructureWorldAccess world, BlockPos pos, BlockState state) {
        BlockState cur = world.getBlockState(pos);
        if (cur.isAir() || cur.isReplaceable()) {
            world.setBlockState(pos, state, Block.NOTIFY_LISTENERS);
        }
    }

    private LepidoTree() {}
}
