package com.haven.mod;

import com.haven.mod.entity.HavenBossEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

public final class ModWorldGen {
    private static RegistryKey<PlacedFeature> feature(String name) {
        return RegistryKey.of(RegistryKeys.PLACED_FEATURE, HavenMod.id(name));
    }

    public static void init() {
        net.minecraft.registry.Registry.register(net.minecraft.registry.Registries.FEATURE, HavenMod.id("lepidodendron"), new LepidoFeature());
        // Руды (сами фичи лежат в data/havenmod/worldgen)
        for (String ore : new String[]{"frostium_ore", "thunderite_ore", "celestite_ore", "havenite_ore"}) {
            BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, feature(ore));
        }
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(), GenerationStep.Feature.UNDERGROUND_ORES, feature("infernium_ore"));

        // Естественный спавн мини-боссов (редкий)
        spawn(ModEntities.FROST_REVENANT, true, 2);
        spawn(ModEntities.STORM_WARDEN, true, 2);
        spawn(ModEntities.MAGMA_BRUTE, false, 4);
    }

    private static void spawn(EntityType<HavenBossEntity> type, boolean overworld, int weight) {
        if (overworld) {
            SpawnRestriction.register(type, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
            BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, type, weight, 1, 1);
        } else {
            SpawnRestriction.register(type, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnIgnoreLightLevel);
            BiomeModifications.addSpawn(BiomeSelectors.foundInTheNether(), SpawnGroup.MONSTER, type, weight, 1, 1);
        }
    }
}
