package com.haven.mod;

import com.haven.mod.entity.HavenBossEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Печать призыва босса. ПКМ - босс появляется перед игроком. */
public class SummonItem extends Item {
    private final EntityType<HavenBossEntity> type;

    public SummonItem(EntityType<HavenBossEntity> type, Settings settings) {
        super(settings);
        this.type = type;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world instanceof ServerWorld serverWorld) {
            HavenBossEntity boss = type.create(serverWorld, SpawnReason.MOB_SUMMONED);
            if (boss != null) {
                Vec3d look = user.getRotationVec(1.0f);
                boss.setPosition(user.getX() + look.x * 5, user.getY(), user.getZ() + look.z * 5);
                boss.setYaw(user.getYaw() + 180f);
                boss.setPersistent();
                serverWorld.spawnEntity(boss);
                user.getStackInHand(hand).decrementUnlessCreative(1, user);
            }
        }
        return ActionResult.SUCCESS;
    }
}
