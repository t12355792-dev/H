package com.haven.mod.client;

import com.haven.mod.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class HavenModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.FROST_REVENANT, ctx -> new HavenBossRenderer(ctx, "frost_revenant"));
        EntityRendererRegistry.register(ModEntities.STORM_WARDEN, ctx -> new HavenBossRenderer(ctx, "storm_warden"));
        EntityRendererRegistry.register(ModEntities.MAGMA_BRUTE, ctx -> new HavenBossRenderer(ctx, "magma_brute"));
        EntityRendererRegistry.register(ModEntities.OLYMPUS_WRATH, ctx -> new HavenBossRenderer(ctx, "olympus_wrath"));
        EntityRendererRegistry.register(ModEntities.HAVEN_OVERLORD, ctx -> new HavenBossRenderer(ctx, "haven_overlord"));
    }
}
