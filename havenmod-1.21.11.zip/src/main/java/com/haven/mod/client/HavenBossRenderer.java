package com.haven.mod.client;

import com.haven.mod.HavenMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.client.render.entity.state.ZombieEntityRenderState;
import net.minecraft.util.Identifier;

public class HavenBossRenderer extends ZombieEntityRenderer {
    private final Identifier texture;

    public HavenBossRenderer(EntityRendererFactory.Context ctx, String name) {
        super(ctx);
        this.texture = HavenMod.id("textures/entity/" + name + ".png");
    }

    @Override
    public Identifier getTexture(ZombieEntityRenderState state) {
        return texture;
    }
}
