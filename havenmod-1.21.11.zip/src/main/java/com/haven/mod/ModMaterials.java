package com.haven.mod;

import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;

import java.util.Map;

public final class ModMaterials {
    public static TagKey<Item> repair(String name) {
        return TagKey.of(RegistryKeys.ITEM, HavenMod.id("repair_" + name));
    }

    /** Бонус урона материала = 0, весь урон задаётся в самом топоре. */
    public static ToolMaterial tool(int durability, float speed, int enchantability, String repairName) {
        return new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, durability, speed, 0.0f, enchantability, repair(repairName));
    }

    public static ArmorMaterial armor(String name, int durability, int helmet, int chest, int legs, int boots,
                                      int enchantability, float toughness, float knockbackResistance) {
        RegistryKey<EquipmentAsset> asset = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, HavenMod.id(name));
        return new ArmorMaterial(durability,
                Map.of(EquipmentType.HELMET, helmet, EquipmentType.CHESTPLATE, chest,
                        EquipmentType.LEGGINGS, legs, EquipmentType.BOOTS, boots, EquipmentType.BODY, chest),
                enchantability, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, toughness, knockbackResistance,
                repair(name), asset);
    }
}
