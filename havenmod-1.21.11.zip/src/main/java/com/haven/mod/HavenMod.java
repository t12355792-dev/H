package com.haven.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class HavenMod implements ModInitializer {
    public static final String MOD_ID = "havenmod";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        ModWorldGen.init();
        LepidoEvents.init();

        // /galaktika - единственный способ получить ТОПОР ГАЛАКТИКИ
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("galaktika").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    player.getInventory().offerOrDrop(new ItemStack(ModItems.GALAXY_AXE));
                    ctx.getSource().sendFeedback(() -> Text.literal("§d§lТОПОР ГАЛАКТИКИ получен!"), false);
                    return 1;
                })));
    }
}
