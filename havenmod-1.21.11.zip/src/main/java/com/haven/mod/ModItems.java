package com.haven.mod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.*;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class ModItems {
    private static final List<Item> TAB = new ArrayList<>();

    // ---- Материалы (дроп с руд) ----
    public static final Item FROSTIUM = simple("frostium");
    public static final Item THUNDERITE = simple("thunderite");
    public static final Item INFERNIUM = simple("infernium");
    public static final Item CELESTITE = simple("celestite");
    public static final Item HAVENITE = simple("havenite");
    public static final Item BOSS_CORE = reg("boss_core", Item::new, new Item.Settings().rarity(Rarity.UNCOMMON), true);

    // ---- Топоры ----
    // Итоговый урон = значение + 1 (базовый урон руки). Кратос 7, Зевс 11, Ад 15, Небеса 25, Галактика 7777.
    public static final Item KRATOS_AXE = reg("kratos_axe",
            s -> new AxeItem(ModMaterials.tool(900, 8f, 15, "frostium"), 6f, -3.0f, s), new Item.Settings(), true);
    public static final Item ZEUS_AXE = reg("zeus_axe",
            s -> new AxeItem(ModMaterials.tool(1500, 9f, 15, "thunderite"), 10f, -3.0f, s), new Item.Settings().rarity(Rarity.UNCOMMON), true);
    public static final Item HELL_AXE = reg("hell_axe",
            s -> new AxeItem(ModMaterials.tool(2500, 10f, 15, "infernium"), 14f, -3.0f, s), new Item.Settings().rarity(Rarity.RARE).fireproof(), true);
    public static final Item HEAVEN_AXE = reg("heaven_axe",
            s -> new AxeItem(ModMaterials.tool(4000, 12f, 20, "celestite"), 24f, -3.0f, s), new Item.Settings().rarity(Rarity.EPIC), true);
    // В креативной вкладке и крафте его НЕТ - только /galaktika
    public static final Item GALAXY_AXE = reg("galaxy_axe",
            s -> new GalaxyAxeItem(ModMaterials.tool(1_000_000, 50f, 30, "havenite"), 7776f, -2.0f, s),
            new Item.Settings().rarity(Rarity.EPIC).fireproof().component(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true), false);

    // ---- Печати призыва боссов ----
    public static final Item SIGIL_OLYMPUS = reg("sigil_olympus",
            s -> new SummonItem(ModEntities.OLYMPUS_WRATH, s), new Item.Settings().maxCount(16).rarity(Rarity.RARE), true);
    public static final Item SIGIL_HAVEN = reg("sigil_haven",
            s -> new SummonItem(ModEntities.HAVEN_OVERLORD, s), new Item.Settings().maxCount(16).rarity(Rarity.EPIC), true);

    static {
        armorSet("frostium", ModMaterials.armor("frostium", 30, 3, 7, 5, 2, 12, 1.0f, 0.0f));
        armorSet("thunderite", ModMaterials.armor("thunderite", 35, 3, 8, 6, 3, 14, 2.0f, 0.0f));
        armorSet("infernium", ModMaterials.armor("infernium", 40, 4, 8, 6, 4, 15, 3.0f, 0.1f));
        armorSet("celestite", ModMaterials.armor("celestite", 44, 4, 9, 7, 4, 18, 3.5f, 0.1f));
        armorSet("havenite", ModMaterials.armor("havenite", 60, 5, 10, 8, 5, 22, 5.0f, 0.2f));
    }

    private static void armorSet(String name, ArmorMaterial mat) {
        reg(name + "_helmet", s -> new Item(s.armor(mat, EquipmentType.HELMET)), new Item.Settings(), true);
        reg(name + "_chestplate", s -> new Item(s.armor(mat, EquipmentType.CHESTPLATE)), new Item.Settings(), true);
        reg(name + "_leggings", s -> new Item(s.armor(mat, EquipmentType.LEGGINGS)), new Item.Settings(), true);
        reg(name + "_boots", s -> new Item(s.armor(mat, EquipmentType.BOOTS)), new Item.Settings(), true);
    }

    private static Item simple(String name) {
        return reg(name, Item::new, new Item.Settings(), true);
    }

    private static <T extends Item> T reg(String name, Function<Item.Settings, T> factory, Item.Settings settings, boolean inTab) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, HavenMod.id(name));
        T item = factory.apply(settings.registryKey(key));
        Registry.register(Registries.ITEM, key, item);
        if (inTab) TAB.add(item);
        return item;
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(GALAXY_AXE))
                .displayName(Text.translatable("itemGroup.havenmod.main"))
                .entries((ctx, entries) -> {
                    ModBlocks.BLOCK_ITEMS.forEach(entries::add);
                    TAB.forEach(entries::add);
                }).build();
        Registry.register(Registries.ITEM_GROUP, HavenMod.id("main"), group);
    }
}
