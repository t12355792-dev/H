package com.haven.mod;

import com.haven.mod.entity.HavenBossEntity;
import com.haven.mod.entity.HavenBossEntity.Kind;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

import java.util.HashMap;
import java.util.Map;

public final class ModEntities {
    public static final Map<EntityType<?>, Kind> KINDS = new HashMap<>();

    // Мини-боссы
    public static final EntityType<HavenBossEntity> FROST_REVENANT = reg("frost_revenant", Kind.FROST, attrs(120, 9, 0.26, 1.4, 6, 0.5));
    public static final EntityType<HavenBossEntity> STORM_WARDEN = reg("storm_warden", Kind.STORM, attrs(160, 11, 0.27, 1.5, 8, 0.6));
    public static final EntityType<HavenBossEntity> MAGMA_BRUTE = reg("magma_brute", Kind.MAGMA, attrs(200, 13, 0.25, 1.6, 10, 0.7));
    // Боссы
    public static final EntityType<HavenBossEntity> OLYMPUS_WRATH = reg("olympus_wrath", Kind.OLYMPUS, attrs(650, 18, 0.28, 2.3, 16, 0.9));
    public static final EntityType<HavenBossEntity> HAVEN_OVERLORD = reg("haven_overlord", Kind.HAVEN, attrs(1500, 26, 0.29, 3.0, 20, 1.0));

    private static DefaultAttributeContainer.Builder attrs(double hp, double dmg, double speed, double scale, double armor, double kb) {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.MAX_HEALTH, hp)
                .add(EntityAttributes.ATTACK_DAMAGE, dmg)
                .add(EntityAttributes.MOVEMENT_SPEED, speed)
                .add(EntityAttributes.SCALE, scale)
                .add(EntityAttributes.ARMOR, armor)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, kb)
                .add(EntityAttributes.FOLLOW_RANGE, 40.0)
                .add(EntityAttributes.SPAWN_REINFORCEMENTS, 0.0);
    }

    private static EntityType<HavenBossEntity> reg(String name, Kind kind, DefaultAttributeContainer.Builder attributes) {
        RegistryKey<EntityType<?>> key = RegistryKey.of(RegistryKeys.ENTITY_TYPE, HavenMod.id(name));
        EntityType<HavenBossEntity> type = EntityType.Builder.create(HavenBossEntity::new, SpawnGroup.MONSTER)
                .dimensions(0.6f, 1.95f).makeFireImmune().maxTrackingRange(10).build(key);
        Registry.register(Registries.ENTITY_TYPE, key, type);
        FabricDefaultAttributeRegistry.register(type, attributes);
        KINDS.put(type, kind);
        return type;
    }

    public static void init() {}
}
