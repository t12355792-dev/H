package com.haven.mod.entity;

import com.haven.mod.ModEntities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

/** Универсальный босс / мини-босс (на базе зомби). Поведение зависит от Kind. */
public class HavenBossEntity extends ZombieEntity {
    public enum Kind { FROST, STORM, MAGMA, OLYMPUS, HAVEN }

    private final ServerBossBar bossBar;
    private int timer = 0;
    private boolean enraged = false;

    public HavenBossEntity(EntityType<? extends HavenBossEntity> type, World world) {
        super(type, world);
        Kind k = ModEntities.KINDS.get(type);
        BossBar.Color color = BossBar.Color.WHITE;
        BossBar.Style style = BossBar.Style.PROGRESS;
        if (k != null) {
            switch (k) {
                case FROST -> color = BossBar.Color.BLUE;
                case STORM -> color = BossBar.Color.YELLOW;
                case MAGMA -> color = BossBar.Color.RED;
                case OLYMPUS -> { color = BossBar.Color.YELLOW; style = BossBar.Style.NOTCHED_12; }
                case HAVEN -> { color = BossBar.Color.PURPLE; style = BossBar.Style.NOTCHED_20; }
            }
        }
        this.bossBar = new ServerBossBar(type.getName(), color, style);
    }

    private Kind kind() {
        return ModEntities.KINDS.get(this.getType());
    }

    @Override
    public boolean isBaby() {
        return false;
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        super.remove(reason);
        bossBar.clearPlayers();
    }

    @Override
    protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        bossBar.setPercent(this.getHealth() / this.getMaxHealth());

        LivingEntity target = this.getTarget();
        Kind kind = kind();
        if (target == null || kind == null || !this.isAlive()) return;
        timer++;

        switch (kind) {
            case FROST -> {
                if (timer % 100 == 0) nova(world, 6, 6f, new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 2), false);
            }
            case STORM -> {
                if (timer % 80 == 0) strike(world, target);
            }
            case MAGMA -> {
                if (timer % 120 == 0) nova(world, 7, 8f, null, true);
            }
            case OLYMPUS -> {
                if (timer % 60 == 0) strike(world, target);
                if (timer % 300 == 0) minions(world, target, 3);
                if (!enraged && this.getHealth() < this.getMaxHealth() * 0.5f) {
                    enraged = true;
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 1));
                }
                if (enraged && timer % 100 == 0) nova(world, 8, 12f, null, false);
            }
            case HAVEN -> {
                if (timer % 50 == 0) strike(world, target);
                if (timer % 200 == 0) minions(world, target, 4);
                if (timer % 140 == 0) nova(world, 9, 14f, new StatusEffectInstance(StatusEffects.WITHER, 120, 1), false);
                if (!enraged && this.getHealth() < this.getMaxHealth() * 0.5f) {
                    enraged = true;
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 2));
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, Integer.MAX_VALUE, 1));
                }
                if (enraged && timer % 60 == 0) strike(world, target);
            }
        }
    }

    @Override
    public boolean tryAttack(ServerWorld world, Entity target) {
        boolean hit = super.tryAttack(world, target);
        if (hit && target instanceof LivingEntity living) {
            Kind kind = kind();
            if (kind != null) {
                switch (kind) {
                    case FROST -> living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
                    case STORM -> living.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 0));
                    case MAGMA -> living.setOnFireFor(6);
                    case OLYMPUS -> strike(world, living);
                    case HAVEN -> {
                        living.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1));
                        living.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
                    }
                }
            }
        }
        return hit;
    }

    private void nova(ServerWorld world, double radius, float damage, StatusEffectInstance effect, boolean fire) {
        for (PlayerEntity p : world.getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(radius),
                pl -> pl.isAlive() && !pl.isSpectator() && !pl.isCreative())) {
            p.damage(world, world.getDamageSources().mobAttack(this), damage);
            if (effect != null) p.addStatusEffect(new StatusEffectInstance(effect));
            if (fire) p.setOnFireFor(5);
            p.takeKnockback(1.3, this.getX() - p.getX(), this.getZ() - p.getZ());
        }
        world.spawnParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 1, this.getZ(), 6, radius / 3, 0.5, radius / 3, 0.0);
    }

    private void strike(ServerWorld world, LivingEntity target) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world, SpawnReason.TRIGGERED);
        if (bolt != null) {
            bolt.setPosition(target.getX(), target.getY(), target.getZ());
            world.spawnEntity(bolt);
        }
    }

    private void minions(ServerWorld world, LivingEntity target, int count) {
        for (int i = 0; i < count; i++) {
            ZombieEntity z = EntityType.ZOMBIE.create(world, SpawnReason.MOB_SUMMONED);
            if (z != null) {
                z.setPosition(this.getX() + this.random.nextInt(7) - 3, this.getY(), this.getZ() + this.random.nextInt(7) - 3);
                z.setTarget(target);
                world.spawnEntity(z);
            }
        }
    }
}
