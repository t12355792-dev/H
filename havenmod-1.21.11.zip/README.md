# Haven Mod (Fabric 1.21.11)

Сборка: `./gradlew build` (или открыть папку в IntelliJ IDEA -> Gradle -> build). Нужна Java 21.
Если нет gradle wrapper: создай шаблон на https://fabricmc.net/develop/template/ и скопируй в него папку `src`
(и значения версий из gradle.properties).

Команды: /galaktika - выдаёт ТОПОР ГАЛАКТИКИ.
Зачарование: havenmod:made_in_haven (+50% урона)
  /give @s minecraft:enchanted_book[stored_enchantments={"havenmod:made_in_haven":1}]
  /enchant @s havenmod:made_in_haven
Мини-боссы: /summon havenmod:frost_revenant (storm_warden, magma_brute)
Боссы: Печать Олимпа / Печать Хейвена (ПКМ) или /summon havenmod:olympus_wrath, havenmod:haven_overlord

## GitHub Actions
Файл `.github/workflows/build.yml` собирает мод при каждом push. Готовый .jar скачивается
на вкладке Actions -> выбери запуск -> Artifacts -> havenmod (берёшь jar БЕЗ -sources).

## Лепидодендрон
- Очень редко появляется рядом с игроком в обычном мире.
- Подойти на 7 блоков и ближе -> телепорт в измерение havenmod:lepidodendron (равнины, туман, деревья везде).
- Там игрок умирает через 2 минуты (таймер в action bar).
- /lepidodendron - дерево вырастает в 20 блоках перед тобой.
- Попасть в измерение вручную: /execute in havenmod:lepidodendron run tp @s 0 100 0
